.class Lnl/joriswit/soko/Play$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lnl/joriswit/soko/Play;->h()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lnl/joriswit/soko/Play;


# direct methods
.method constructor <init>(Lnl/joriswit/soko/Play;)V
    .registers 2

    iput-object p1, p0, Lnl/joriswit/soko/Play$1;->a:Lnl/joriswit/soko/Play;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 3

    iget-object v0, p0, Lnl/joriswit/soko/Play$1;->a:Lnl/joriswit/soko/Play;

    invoke-static {v0}, Lnl/joriswit/soko/Play;->a(Lnl/joriswit/soko/Play;)Lnl/joriswit/soko/a/g;

    move-result-object v0

    invoke-virtual {v0}, Lnl/joriswit/soko/a/g;->j()Z

    move-result v0

    if-eqz v0, :cond_11

    iget-object v0, p0, Lnl/joriswit/soko/Play$1;->a:Lnl/joriswit/soko/Play;

    invoke-virtual {v0}, Lnl/joriswit/soko/Play;->c()V

    :cond_11
    return-void
.end method
