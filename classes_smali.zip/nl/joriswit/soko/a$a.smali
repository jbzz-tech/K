.class Lnl/joriswit/soko/a$a;
.super Lnl/joriswit/soko/a;


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0x13
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lnl/joriswit/soko/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lnl/joriswit/soko/a;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lnl/joriswit/soko/a$1;)V
    .registers 2

    invoke-direct {p0}, Lnl/joriswit/soko/a$a;-><init>()V

    return-void
.end method


# virtual methods
.method b(Landroid/content/ContentResolver;Landroid/net/Uri;)Z
    .registers 4

    invoke-static {p1, p2}, Landroid/provider/DocumentsContract;->deleteDocument(Landroid/content/ContentResolver;Landroid/net/Uri;)Z

    move-result v0

    return v0
.end method
