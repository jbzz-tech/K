.class Landroid/support/v4/view/w;
.super Ljava/lang/Object;


# direct methods
.method public static a(Landroid/view/ViewConfiguration;)I
    .registers 2

    invoke-virtual {p0}, Landroid/view/ViewConfiguration;->getScaledPagingTouchSlop()I

    move-result v0

    return v0
.end method
