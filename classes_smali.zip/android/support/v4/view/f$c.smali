.class Landroid/support/v4/view/f$c;
.super Landroid/support/v4/view/f$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/v4/view/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "c"
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/support/v4/view/f$b;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/view/LayoutInflater;Landroid/support/v4/view/j;)V
    .registers 3

    invoke-static {p1, p2}, Landroid/support/v4/view/h;->a(Landroid/view/LayoutInflater;Landroid/support/v4/view/j;)V

    return-void
.end method
