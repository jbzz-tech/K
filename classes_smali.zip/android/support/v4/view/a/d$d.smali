.class Landroid/support/v4/view/a/d$d;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/support/v4/view/a/d$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/v4/view/a/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "d"
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/support/v4/view/a/d;)Ljava/lang/Object;
    .registers 3

    const/4 v0, 0x0

    return-object v0
.end method
