.class interface abstract Landroid/support/v4/view/ViewPager$e;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/v4/view/ViewPager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "e"
.end annotation


# virtual methods
.method public abstract a(Landroid/support/v4/view/m;Landroid/support/v4/view/m;)V
.end method
