.class Landroid/support/v4/a/d$2;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/ViewTreeObserver$OnPreDrawListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroid/support/v4/a/d;->a(Landroid/support/v4/a/d$b;Landroid/view/View;Ljava/lang/Object;Landroid/support/v4/a/f;Landroid/support/v4/a/f;ZLjava/util/ArrayList;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/view/View;

.field final synthetic b:Ljava/lang/Object;

.field final synthetic c:Ljava/util/ArrayList;

.field final synthetic d:Landroid/support/v4/a/d$b;

.field final synthetic e:Z

.field final synthetic f:Landroid/support/v4/a/f;

.field final synthetic g:Landroid/support/v4/a/f;

.field final synthetic h:Landroid/support/v4/a/d;


# direct methods
.method constructor <init>(Landroid/support/v4/a/d;Landroid/view/View;Ljava/lang/Object;Ljava/util/ArrayList;Landroid/support/v4/a/d$b;ZLandroid/support/v4/a/f;Landroid/support/v4/a/f;)V
    .registers 9

    iput-object p1, p0, Landroid/support/v4/a/d$2;->h:Landroid/support/v4/a/d;

    iput-object p2, p0, Landroid/support/v4/a/d$2;->a:Landroid/view/View;

    iput-object p3, p0, Landroid/support/v4/a/d$2;->b:Ljava/lang/Object;

    iput-object p4, p0, Landroid/support/v4/a/d$2;->c:Ljava/util/ArrayList;

    iput-object p5, p0, Landroid/support/v4/a/d$2;->d:Landroid/support/v4/a/d$b;

    iput-boolean p6, p0, Landroid/support/v4/a/d$2;->e:Z

    iput-object p7, p0, Landroid/support/v4/a/d$2;->f:Landroid/support/v4/a/f;

    iput-object p8, p0, Landroid/support/v4/a/d$2;->g:Landroid/support/v4/a/f;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onPreDraw()Z
    .registers 7

    iget-object v0, p0, Landroid/support/v4/a/d$2;->a:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    iget-object v0, p0, Landroid/support/v4/a/d$2;->b:Ljava/lang/Object;

    if-eqz v0, :cond_52

    iget-object v0, p0, Landroid/support/v4/a/d$2;->b:Ljava/lang/Object;

    iget-object v1, p0, Landroid/support/v4/a/d$2;->c:Ljava/util/ArrayList;

    invoke-static {v0, v1}, Landroid/support/v4/a/o;->a(Ljava/lang/Object;Ljava/util/ArrayList;)V

    iget-object v0, p0, Landroid/support/v4/a/d$2;->c:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p0, Landroid/support/v4/a/d$2;->h:Landroid/support/v4/a/d;

    iget-object v1, p0, Landroid/support/v4/a/d$2;->d:Landroid/support/v4/a/d$b;

    iget-boolean v2, p0, Landroid/support/v4/a/d$2;->e:Z

    iget-object v3, p0, Landroid/support/v4/a/d$2;->f:Landroid/support/v4/a/f;

    invoke-static {v0, v1, v2, v3}, Landroid/support/v4/a/d;->a(Landroid/support/v4/a/d;Landroid/support/v4/a/d$b;ZLandroid/support/v4/a/f;)Landroid/support/v4/d/a;

    move-result-object v5

    iget-object v0, p0, Landroid/support/v4/a/d$2;->c:Ljava/util/ArrayList;

    iget-object v1, p0, Landroid/support/v4/a/d$2;->d:Landroid/support/v4/a/d$b;

    iget-object v1, v1, Landroid/support/v4/a/d$b;->d:Landroid/view/View;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Landroid/support/v4/a/d$2;->c:Ljava/util/ArrayList;

    invoke-virtual {v5}, Landroid/support/v4/d/a;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p0, Landroid/support/v4/a/d$2;->b:Ljava/lang/Object;

    iget-object v1, p0, Landroid/support/v4/a/d$2;->c:Ljava/util/ArrayList;

    invoke-static {v0, v1}, Landroid/support/v4/a/o;->b(Ljava/lang/Object;Ljava/util/ArrayList;)V

    iget-object v0, p0, Landroid/support/v4/a/d$2;->h:Landroid/support/v4/a/d;

    iget-object v1, p0, Landroid/support/v4/a/d$2;->d:Landroid/support/v4/a/d$b;

    invoke-static {v0, v5, v1}, Landroid/support/v4/a/d;->a(Landroid/support/v4/a/d;Landroid/support/v4/d/a;Landroid/support/v4/a/d$b;)V

    iget-object v0, p0, Landroid/support/v4/a/d$2;->h:Landroid/support/v4/a/d;

    iget-object v1, p0, Landroid/support/v4/a/d$2;->d:Landroid/support/v4/a/d$b;

    iget-object v2, p0, Landroid/support/v4/a/d$2;->f:Landroid/support/v4/a/f;

    iget-object v3, p0, Landroid/support/v4/a/d$2;->g:Landroid/support/v4/a/f;

    iget-boolean v4, p0, Landroid/support/v4/a/d$2;->e:Z

    invoke-static/range {v0 .. v5}, Landroid/support/v4/a/d;->a(Landroid/support/v4/a/d;Landroid/support/v4/a/d$b;Landroid/support/v4/a/f;Landroid/support/v4/a/f;ZLandroid/support/v4/d/a;)V

    :cond_52
    const/4 v0, 0x1

    return v0
.end method
